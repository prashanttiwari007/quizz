package jorge.rv.quizzz.model;

public interface UserOwned {
	User getUser();
}
