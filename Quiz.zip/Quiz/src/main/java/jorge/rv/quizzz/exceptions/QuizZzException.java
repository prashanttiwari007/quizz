package jorge.rv.quizzz.exceptions;

public class QuizZzException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public QuizZzException() {
		super();
	}

	public QuizZzException(String message) {
		super(message);
	}
}
