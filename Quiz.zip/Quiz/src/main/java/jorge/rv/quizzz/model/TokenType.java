package jorge.rv.quizzz.model;

public enum TokenType {
	REGISTRATION_MAIL, FORGOT_PASSWORD
}
